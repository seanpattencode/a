import subprocess as sp, time
from pathlib import Path

ROOT, DEVICES = Path(__file__).parent / 'devices', ('device_a', 'device_b', 'device_c')

def setup(): sp.run(f'rm -rf {ROOT} && mkdir -p {ROOT/"origin"} && git -C {ROOT/"origin"} init -q -b main --bare', shell=True); [sp.run(f'mkdir -p {ROOT/d} && git -C {ROOT/d} init -q -b main && git -C {ROOT/d} remote add origin {ROOT/"origin"}', shell=True) for d in DEVICES]

def create_file(device, name, content=''): ts=time.strftime('%Y%m%dT%H%M%S')+f'.{time.time_ns()%1000000000:09d}'; p=ROOT/device/f'{name}_{ts}.txt'; p.write_text(content or f'created by {device}'); sp.run(f'cd {ROOT/device} && git add -A && git commit -qm "add {p.name}" && git push -u origin main', shell=True); return p.name

def pull(device): sp.run(f'cd {ROOT/device} && git pull -q origin main', shell=True)

def run_n(n): [(pull(d), create_file(d, f'note{i}'), [pull(x) for x in DEVICES]) for i in range(n) for d in DEVICES]; return {d: len(list((ROOT/d).glob('*.txt'))) for d in DEVICES}

if __name__ == '__main__': setup(); print(run_n(5))
